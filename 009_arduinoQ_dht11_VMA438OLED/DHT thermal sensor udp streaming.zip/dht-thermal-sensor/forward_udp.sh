#!/bin/sh
# Forward a UDP port from the board to the app's Docker container.
#
# The app runs on a private Docker network and app.yaml publishes no ports,
# so the PC cannot reach the UDP server directly. This starts a socat relay
# on the board (no root needed) that forwards PORT/udp to the container.
#
# Run it ON THE BOARD:
#   sh forward_udp.sh start      # start (or restart) the relay once
#   sh forward_udp.sh stop       # stop the relay and the watcher
#   sh forward_udp.sh status     # show the relay and the watcher
#   sh forward_udp.sh watch      # start the watcher in the background: it keeps
#                                # the relay pointed at the app's container,
#                                # across app restarts
#   sh forward_udp.sh install    # launch the watcher at every board boot (cron)
#   sh forward_udp.sh uninstall  # remove the boot entry
#
# Options (environment variables):
#   PORT=50555                       UDP port to forward
#   CONTAINER=<name>                 container to forward to (auto-detected)

# Set to 0 once app.yaml publishes the port itself: within CHECK_EVERY seconds
# the watcher stops the relay (freeing the port for Docker) and exits, and it
# no longer starts at boot.
WATCH_ENABLED=1

PORT="${PORT:-50555}"
CHECK_EVERY=10
APP_NAME="dht-thermal-sensor-20261111-123808"
SCRIPT="$(cd "$(dirname "$0")" && pwd)/$(basename "$0")"
PIDFILE="/tmp/udp-forward-$PORT.pid"
TARGETFILE="/tmp/udp-forward-$PORT.target"
WATCHPIDFILE="/tmp/udp-forward-$PORT.watch.pid"
LOGFILE="/tmp/udp-forward-$PORT.log"
CRON_LINE="@reboot sh '$SCRIPT' watch"

# Read the flag from the file each time, so an edit applies to a running watcher.
watch_enabled() {
    grep -q '^WATCH_ENABLED=1' "$SCRIPT"
}

is_running() {
    [ -f "$1" ] && kill -0 "$(cat "$1")" 2>/dev/null
}

find_container() {
    if [ -n "$CONTAINER" ]; then
        echo "$CONTAINER"
    else
        docker ps --filter "name=$APP_NAME" --format '{{.Names}}' | head -n 1
    fi
}

container_ip() {
    docker inspect -f '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' "$1" 2>/dev/null
}

stop_relay() {
    if [ -f "$PIDFILE" ]; then
        pid=$(cat "$PIDFILE")
        if kill "$pid" 2>/dev/null; then
            echo "relay stopped (pid $pid)"
        fi
        rm -f "$PIDFILE" "$TARGETFILE"
    fi
}

stop_watch() {
    if [ -f "$WATCHPIDFILE" ]; then
        pid=$(cat "$WATCHPIDFILE")
        if kill "$pid" 2>/dev/null; then
            echo "watcher stopped (pid $pid)"
        fi
        rm -f "$WATCHPIDFILE"
    fi
}

start_relay() {
    command -v socat >/dev/null || { echo "error: socat is not installed" >&2; return 1; }

    name=$(find_container)
    [ -n "$name" ] || { echo "error: app container not found - is the app running?" >&2; return 1; }

    ip=$(container_ip "$name")
    [ -n "$ip" ] || { echo "error: no IP for container $name" >&2; return 1; }

    stop_relay
    setsid nohup socat "UDP4-LISTEN:$PORT,fork,reuseaddr" "UDP4:$ip:$PORT" \
        >"$LOGFILE" 2>&1 </dev/null &
    echo $! >"$PIDFILE"
    sleep 1

    if is_running "$PIDFILE"; then
        echo "$ip" >"$TARGETFILE"
        echo "relay started: board :$PORT/udp -> $name ($ip:$PORT)"
        echo "board addresses: $(hostname -I)"
    else
        echo "error: relay did not start, see $LOGFILE" >&2
        rm -f "$PIDFILE"
        return 1
    fi
}

# Every CHECK_EVERY seconds: (re)start the relay when the container appears or
# its IP changes; stop everything once WATCH_ENABLED is set to 0.
watch_loop() {
    echo $$ >"$WATCHPIDFILE"
    while true; do
        if ! watch_enabled; then
            echo "$(date '+%F %T') WATCH_ENABLED=0: stopping"
            stop_relay
            rm -f "$WATCHPIDFILE"
            exit 0
        fi
        name=$(find_container)
        if [ -n "$name" ]; then
            ip=$(container_ip "$name")
            if [ -n "$ip" ] && { ! is_running "$PIDFILE" || [ "$(cat "$TARGETFILE" 2>/dev/null)" != "$ip" ]; }; then
                msg=$(start_relay 2>&1)
                echo "$(date '+%F %T') $msg"
            fi
        fi
        sleep "$CHECK_EVERY"
    done
}

start_watch() {
    watch_enabled || { echo "watcher disabled (WATCH_ENABLED=0 in $SCRIPT)"; return 0; }
    if is_running "$WATCHPIDFILE"; then
        echo "watcher already running (pid $(cat "$WATCHPIDFILE"))"
        return 0
    fi
    setsid nohup sh "$SCRIPT" watch-loop >>"$LOGFILE.watch" 2>&1 </dev/null &
    sleep 1
    echo "watcher started (pid $(cat "$WATCHPIDFILE")), log: $LOGFILE.watch"
}

install_boot() {
    if crontab -l 2>/dev/null | grep -qF "$SCRIPT"; then
        echo "boot entry already installed"
    else
        (crontab -l 2>/dev/null; echo "$CRON_LINE") | crontab -
        echo "boot entry installed: $CRON_LINE"
    fi
}

uninstall_boot() {
    crontab -l 2>/dev/null | grep -vF "$SCRIPT" | crontab -
    echo "boot entry removed"
}

status_all() {
    if is_running "$PIDFILE"; then
        echo "relay running (pid $(cat "$PIDFILE")) -> $(cat "$TARGETFILE" 2>/dev/null):$PORT"
    else
        echo "relay not running"
    fi
    if is_running "$WATCHPIDFILE"; then
        echo "watcher running (pid $(cat "$WATCHPIDFILE"))"
    else
        echo "watcher not running"
    fi
    watch_enabled && echo "WATCH_ENABLED=1" || echo "WATCH_ENABLED=0"
    crontab -l 2>/dev/null | grep -qF "$SCRIPT" && echo "boot entry installed" || echo "boot entry not installed"
}

case "$1" in
    start) start_relay ;;
    stop) stop_watch; stop_relay ;;
    status) status_all ;;
    watch) start_watch ;;
    watch-loop) watch_loop ;;
    install) install_boot ;;
    uninstall) uninstall_boot ;;
    *) echo "usage: sh $0 {start|stop|status|watch|install|uninstall}" >&2; exit 2 ;;
esac
