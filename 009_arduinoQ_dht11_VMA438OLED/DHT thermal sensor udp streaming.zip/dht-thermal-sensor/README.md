# DHT thermal sensor

## Important: 
the script forwar_udp.sh install must be run to forward the  
udp port from the docker container (mount point: ~/ArduinoApps/dht-thermal-sensor).

Reads temperature and humidity from a DHT11/DHT22 sensor every 2 s, prints the
values in the Python log, and shows them on a VMA438 OLED screen
(0.96", 128x64, SSD1306 controller, I2C address 0x3C).

## Wiring (Arduino UNO Q)

```
        DHT11 / DHT22                      UNO Q
     +---------------+
     |  VCC (+)      |------------------- 3.3V
     |  DATA (OUT)   |------------------- D2
     |  GND (-)      |------------------- GND
     +---------------+

        VMA438 OLED                        UNO Q
     +---------------+
     |  GND          |------------------- GND
     |  VCC          |------------------- 3.3V   (NOT 5V, see note)
     |  SCL          |------------------- SCL    (header pin next to AREF)
     |  SDA          |------------------- SDA    (header pin next to SCL)
     +---------------+
```

Notes:
- Power the OLED from **3.3V**. Its on-board pull-up resistors tie SDA/SCL to VCC,
  and the UNO Q MCU pins are 3.3 V only.
- Use the SDA/SCL header pins (`Wire`), not the Qwiic connector (`Wire1`).
- Bare DHT sensors (4 pins) need a 4.7–10 kΩ pull-up between DATA and VCC;
  3-pin breakout modules already have one.

## Screen

```
+------------------------------+
| CLIMATE MONITOR            o |  <- dot blinks on every read
|  _      |   /\               |
| | | 23.4|  /  \  56%         |
| |#| °C  |  \__/  RH          |
| (#)     |        [#####   ]  |
+------------------------------+
```

If the sensor can't be read, the screen shows "Sensor read error" and the failure stage.
