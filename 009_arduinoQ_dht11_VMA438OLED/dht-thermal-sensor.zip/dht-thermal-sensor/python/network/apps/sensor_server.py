"""DHT SENSOR SERVER -- runs on the Arduino UNO Q (Linux side, inside App Lab).

The sketch (sketch/sketch.ino) reads the DHT11/DHT22 every 2 s and notifies the
Python side through the Arduino Bridge:

    Bridge.notify("dht_reading", temperature, humidity)
    Bridge.notify("dht_error",   stage, idle_level, release_us)

This module turns each notification into one 'key=value;key=value' string and
broadcasts it over udp_link to every connected client (pc_client.py on a PC):

    temp=23.4;hum=56.0;seq=12;ts=1731340000.123
    error=read;stage=3;idle=1;release_us=12;seq=13;ts=1731340002.125

    seq  counter of notifications since start: the client uses it to spot gaps
    ts   moment of the reading (seconds since 1970): the client shows its age

How it is started
-----------------
On the board, App Lab runs python/main.py. main.py creates a SensorServer,
starts it, and calls publish_reading() / publish_error() from its Bridge
callbacks. App.run() owns the main thread, so the UDP server lives in its own
background thread (udp_link.bridge.LinkThread): nothing here blocks the Bridge.

Without the board (to test the link from any machine), run it as a program
with simulated readings:

    python3 -m apps.sensor_server --config link.toml --simulate

Configuration: link.toml (same file, same secret on the board and on the PC).
It is looked up in the current folder, then in python/network/.
"""

from __future__ import annotations

import argparse  # command-line options (--simulate mode only)
import logging
import os
import random  # only used by --simulate
import threading
import time

from udp_link import LinkConfig, add_cli_args, config_from_cli
from udp_link.bridge import LinkThread

from apps._common import setup_logging

log = logging.getLogger("sensor_server")


def format_reading(temperature: float, humidity: float, seq: int, ts: float | None = None) -> str:
    """'temp=23.4;hum=56.0;seq=12;ts=1731340000.123' (what the client parses)."""
    ts = time.time() if ts is None else ts
    return f"temp={temperature:.1f};hum={humidity:.1f};seq={seq};ts={ts:.3f}"


def format_error(stage: int, idle_level: int, release_us: int, seq: int, ts: float | None = None) -> str:
    """'error=read;stage=3;idle=1;release_us=12;seq=13;ts=...' (a failed sensor read)."""
    ts = time.time() if ts is None else ts
    return f"error=read;stage={stage};idle={idle_level};release_us={release_us};seq={seq};ts={ts:.3f}"


class SensorServer:
    """Broadcasts DHT readings to every connected udp_link client.

    Thread-safe: publish_reading() / publish_error() can be called from the
    Bridge callbacks (any thread); they never block.

        server = SensorServer().start()
        server.publish_reading(23.4, 56.0)
        ...
        server.close()
    """

    def __init__(self, config: LinkConfig | str | os.PathLike[str] | None = None) -> None:
        # latest_only=True: if a client is slow (ACK pending), a newer reading
        # replaces the queued one instead of building a backlog.
        self.link = LinkThread("server", config, on_text=self._on_client_text, latest_only=True)
        self.last: str | None = None  # last string published (reading or error)
        self._seq = 0
        self._lock = threading.Lock()  # Bridge callbacks may come from several threads

    # ------------------------------------------------------------- lifecycle
    def start(self) -> SensorServer:
        self.link.start()
        cfg = self.link.config
        log.info("sensor server listening on %s:%d (udp)", cfg.bind_ip, cfg.port)
        return self

    def close(self) -> None:
        self.link.close()

    def __enter__(self) -> SensorServer:
        return self.start()

    def __exit__(self, *_exc) -> None:
        self.close()

    # ------------------------------------------------------------ publishing
    def publish_reading(self, temperature: float, humidity: float) -> str:
        """Send one good reading to every client; returns the string sent."""
        return self._publish(lambda seq: format_reading(temperature, humidity, seq))

    def publish_error(self, stage: int, idle_level: int, release_us: int) -> str:
        """Send one failed-read report to every client; returns the string sent."""
        return self._publish(lambda seq: format_error(stage, idle_level, release_us, seq))

    def _publish(self, build) -> str:
        with self._lock:
            self._seq += 1
            text = build(self._seq)
            self.last = text
        if self.link.error is not None:
            # The link thread stopped (e.g. port already in use): keep the app
            # running (OLED + local log) but say why nothing is sent.
            log.debug("link down (%s), not sent: %s", self.link.error, text)
            return text
        self.link.send(text)
        log.debug("-> %s", text)
        return text

    # ------------------------------------------------------------- receiving
    def _on_client_text(self, text: str) -> None:
        # Strings a client sends us (e.g. 'hello from pc_client'). Runs in the link thread.
        log.info("<- client: %r", text)
        if text.strip() == "get" and self.last is not None:
            # A client asking for the latest value right away (instead of
            # waiting for the next 2 s tick): send it again.
            self.link.send(self.last)


# --------------------------------------------------------------------------
# Standalone mode (no board): python3 -m apps.sensor_server --simulate
# --------------------------------------------------------------------------
def _simulate(server: SensorServer, interval: float, error_rate: float) -> None:
    """Publish fake readings every `interval` seconds, like the sketch does."""
    temp, hum = 21.0, 45.0
    while True:
        if random.random() < error_rate:
            text = server.publish_error(stage=random.choice([1, 2, 3, 99]), idle_level=1, release_us=10)
        else:
            temp += random.uniform(-0.2, 0.2)
            hum = min(100.0, max(0.0, hum + random.uniform(-0.5, 0.5)))
            text = server.publish_reading(temp, hum)
        log.info("-> %s", text)
        time.sleep(interval)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    add_cli_args(parser)  # --config, --server-ip, --bind-ip, --port
    parser.add_argument("--simulate", action="store_true", help="publish fake readings (no board / no Bridge needed)")
    parser.add_argument("--interval", type=float, default=2.0, help="seconds between simulated readings (default 2)")
    parser.add_argument("--error-rate", type=float, default=0.05, help="share of simulated failed reads (default 0.05)")
    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args()
    setup_logging(args.verbose)

    server = SensorServer(config_from_cli(args)).start()
    try:
        if args.simulate:
            _simulate(server, args.interval, args.error_rate)
        else:
            # On the board, outside main.py: hook the Bridge ourselves.
            try:
                from arduino.app_utils import App, Bridge
            except ImportError:
                parser.error("arduino.app_utils not found: run inside App Lab (python/main.py) or use --simulate")
            Bridge.provide("dht_reading", server.publish_reading)
            Bridge.provide("dht_error", server.publish_error)
            App.run()
    except KeyboardInterrupt:
        pass
    finally:
        server.close()


if __name__ == "__main__":
    main()
