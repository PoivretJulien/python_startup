import logging
import sys
from pathlib import Path

from arduino.app_utils import App, Bridge

# The udp_link library and the apps live in python/network/
sys.path.insert(0, str(Path(__file__).resolve().parent / "network"))

from apps.sensor_server import SensorServer  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)-7s %(name)s: %(message)s", datefmt="%H:%M:%S")

# UDP server that forwards every reading to the PC client (pc_client.py).
# Needs python/network/link.toml (same secret as on the PC). If it is missing
# or invalid, the app keeps running (OLED + log) without the network part.
try:
    server = SensorServer().start()
except Exception as exc:
    print(f"Network disabled: {exc}")
    server = None


# Called by the sketch every 2 seconds with a new reading
def dht_reading(temperature: float, humidity: float):
    print(f"Temperature: {temperature:.1f} °C  Humidity: {humidity:.1f} %")
    if server is not None:
        server.publish_reading(temperature, humidity)


def dht_error(stage: int, idle_level: int, release_us: int):
    print(f"Failed to read DHT22 - stage={stage} idle_level={idle_level} release_us={release_us}")
    if server is not None:
        server.publish_error(stage, idle_level, release_us)


Bridge.provide("dht_reading", dht_reading)
Bridge.provide("dht_error", dht_error)

App.run()
