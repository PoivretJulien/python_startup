#include <Arduino_RouterBridge.h>
#include <Wire.h>

#define DHT_PIN 2   // DHT22 data (OUT) wire -> pin D2

// Wait while the pin stays at `level`; returns the time spent in us, or -1 on timeout
long waitWhile(int level, unsigned long timeout_us) {
  unsigned long start = micros();
  while (digitalRead(DHT_PIN) == level) {
    if (micros() - start > timeout_us) return -1;
  }
  return micros() - start;
}

// Diagnostics: where the last read failed
int errStage = 0;     // 1..3 = handshake step, 10+i = bit i, 99 = checksum
int idleLevel = -1;   // line level before the start signal (should be 1)
long releaseUs = 0;   // time pinMode(INPUT_PULLUP) took

bool readDHT22Raw(float &temperature, float &humidity);

// Reads the sensor with interrupts off, so no bit is missed
bool readDHT22(float &temperature, float &humidity) {
  bool ok = readDHT22Raw(temperature, humidity);
  temperature += 3.0;
  interrupts();
  return ok;
}

// Reads the DHT22; returns false on timeout or checksum error
bool readDHT22Raw(float &temperature, float &humidity) {
  uint8_t data[5] = {0, 0, 0, 0, 0};
  errStage = 0;
  idleLevel = digitalRead(DHT_PIN);

  // Start signal: pull the line low for >1 ms, then release it
  pinMode(DHT_PIN, OUTPUT);
  digitalWrite(DHT_PIN, LOW);
  delay(20);   // DHT11 needs >= 18 ms, DHT22 accepts it too
  noInterrupts();   // timing-critical part starts here
  unsigned long t0 = micros();
  pinMode(DHT_PIN, INPUT_PULLUP);
  releaseUs = micros() - t0;

  // Sensor answers: (high) -> low 80 us -> high 80 us
  if (waitWhile(HIGH, 300) < 0) { errStage = 1; return false; }
  if (waitWhile(LOW, 300) < 0) { errStage = 2; return false; }
  if (waitWhile(HIGH, 300) < 0) { errStage = 3; return false; }

  // 40 bits: 50 us low, then high ~27 us (0) or ~70 us (1)
  for (int i = 0; i < 40; i++) {
    if (waitWhile(LOW, 300) < 0) { errStage = 10 + i; return false; }
    long highTime = waitWhile(HIGH, 300);
    if (highTime < 0) { errStage = 10 + i; return false; }
    data[i / 8] <<= 1;
    if (highTime > 45) data[i / 8] |= 1;
  }

  if (((data[0] + data[1] + data[2] + data[3]) & 0xFF) != data[4]) { errStage = 99; return false; }

  if (data[0] > 3) {
    // DHT11 format: integer + decimal bytes
    humidity = data[0] + data[1] * 0.1;
    temperature = (data[2] & 0x7F) + data[3] * 0.1;
  } else {
    // DHT22 format: 16-bit values x10
    humidity = ((data[0] << 8) | data[1]) * 0.1;
    temperature = (((data[2] & 0x7F) << 8) | data[3]) * 0.1;
  }
  if (data[2] & 0x80) temperature = -temperature;
  return true;
}

// ---------------------------------------------------------------------------
// VMA438 = 0.96" 128x64 SSD1306 OLED on I2C (SDA/SCL header pins), address 0x3C.
// Small built-in driver: only uses Wire, so it compiles on the UNO Q's Zephyr core.

#define OLED_W 128
#define OLED_H 64
#define OLED_ADDR 0x3C

uint8_t fb[OLED_W * OLED_H / 8];   // frame buffer, 1 bit per pixel
bool oledOk = false;
int frame = 0;   // toggles the "alive" dot

void oledCommand(uint8_t c) {
  Wire.beginTransmission(OLED_ADDR);
  Wire.write(0x00);   // control byte: command
  Wire.write(c);
  Wire.endTransmission();
}

bool oledBegin() {
  Wire.beginTransmission(OLED_ADDR);
  if (Wire.endTransmission() != 0) return false;   // nothing answers at 0x3C

  const uint8_t init[] = {
    0xAE, 0xD5, 0x80, 0xA8, 0x3F, 0xD3, 0x00, 0x40, 0x8D, 0x14,
    0x20, 0x00, 0xA1, 0xC8, 0xDA, 0x12, 0x81, 0xCF, 0xD9, 0xF1,
    0xDB, 0x40, 0xA4, 0xA6, 0x2E, 0xAF
  };
  for (uint8_t c : init) oledCommand(c);
  return true;
}

void oledShow() {
  oledCommand(0x21); oledCommand(0); oledCommand(OLED_W - 1);   // column range
  oledCommand(0x22); oledCommand(0); oledCommand(7);            // page range
  for (unsigned i = 0; i < sizeof(fb); i += 16) {
    Wire.beginTransmission(OLED_ADDR);
    Wire.write(0x40);   // control byte: data
    for (int j = 0; j < 16; j++) Wire.write(fb[i + j]);
    Wire.endTransmission();
  }
}

void clearFb() { memset(fb, 0, sizeof(fb)); }

void setPixel(int x, int y, bool on) {
  if (x < 0 || x >= OLED_W || y < 0 || y >= OLED_H) return;
  if (on) fb[x + (y / 8) * OLED_W] |= (1 << (y & 7));
  else    fb[x + (y / 8) * OLED_W] &= ~(1 << (y & 7));
}

void fillRect(int x, int y, int w, int h, bool on) {
  for (int i = x; i < x + w; i++)
    for (int j = y; j < y + h; j++) setPixel(i, j, on);
}

void drawRect(int x, int y, int w, int h) {
  fillRect(x, y, w, 1, true);
  fillRect(x, y + h - 1, w, 1, true);
  fillRect(x, y, 1, h, true);
  fillRect(x + w - 1, y, 1, h, true);
}

void drawLine(int x0, int y0, int x1, int y1) {
  int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
  int dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
  int err = dx + dy;
  while (true) {
    setPixel(x0, y0, true);
    if (x0 == x1 && y0 == y1) break;
    int e2 = 2 * err;
    if (e2 >= dy) { err += dy; x0 += sx; }
    if (e2 <= dx) { err += dx; y0 += sy; }
  }
}

void fillCircle(int cx, int cy, int r, bool on) {
  for (int dy = -r; dy <= r; dy++)
    for (int dx = -r; dx <= r; dx++)
      if (dx * dx + dy * dy <= r * r) setPixel(cx + dx, cy + dy, on);
}

void drawCircle(int cx, int cy, int r) {
  for (int dy = -r; dy <= r; dy++)
    for (int dx = -r; dx <= r; dx++) {
      int d = dx * dx + dy * dy;
      if (d >= r * r - r && d <= r * r + r) setPixel(cx + dx, cy + dy, true);
    }
}

// 5x7 font, one byte per column (bit 0 = top). '*' is drawn as a degree sign.
const char GLYPHS[] = " %-.0123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZ*";
const uint8_t FONT[][5] = {
  {0x00,0x00,0x00,0x00,0x00}, {0x23,0x13,0x08,0x64,0x62}, {0x08,0x08,0x08,0x08,0x08},
  {0x00,0x60,0x60,0x00,0x00}, {0x3E,0x51,0x49,0x45,0x3E}, {0x00,0x42,0x7F,0x40,0x00},
  {0x42,0x61,0x51,0x49,0x46}, {0x21,0x41,0x45,0x4B,0x31}, {0x18,0x14,0x12,0x7F,0x10},
  {0x27,0x45,0x45,0x45,0x39}, {0x3C,0x4A,0x49,0x49,0x30}, {0x01,0x71,0x09,0x05,0x03},
  {0x36,0x49,0x49,0x49,0x36}, {0x06,0x49,0x49,0x29,0x1E}, {0x00,0x36,0x36,0x00,0x00},
  {0x7E,0x11,0x11,0x11,0x7E}, {0x7F,0x49,0x49,0x49,0x36}, {0x3E,0x41,0x41,0x41,0x22},
  {0x7F,0x41,0x41,0x22,0x1C}, {0x7F,0x49,0x49,0x49,0x41}, {0x7F,0x09,0x09,0x09,0x01},
  {0x3E,0x41,0x49,0x49,0x7A}, {0x7F,0x08,0x08,0x08,0x7F}, {0x00,0x41,0x7F,0x41,0x00},
  {0x20,0x40,0x41,0x3F,0x01}, {0x7F,0x08,0x14,0x22,0x41}, {0x7F,0x40,0x40,0x40,0x40},
  {0x7F,0x02,0x0C,0x02,0x7F}, {0x7F,0x04,0x08,0x10,0x7F}, {0x3E,0x41,0x41,0x41,0x3E},
  {0x7F,0x09,0x09,0x09,0x06}, {0x3E,0x41,0x51,0x21,0x5E}, {0x7F,0x09,0x19,0x29,0x46},
  {0x46,0x49,0x49,0x49,0x31}, {0x01,0x01,0x7F,0x01,0x01}, {0x3F,0x40,0x40,0x40,0x3F},
  {0x1F,0x20,0x40,0x20,0x1F}, {0x3F,0x40,0x38,0x40,0x3F}, {0x63,0x14,0x08,0x14,0x63},
  {0x07,0x08,0x70,0x08,0x07}, {0x61,0x51,0x49,0x45,0x43}, {0x00,0x06,0x09,0x09,0x06},
};

// Draws text at (x, y) scaled by `size`; on = white text, off = black text
void drawText(int x, int y, const char *s, int size, bool on = true) {
  for (; *s; s++, x += 6 * size) {
    const char *p = strchr(GLYPHS, toupper(*s));
    if (!p) continue;
    const uint8_t *g = FONT[p - GLYPHS];
    for (int col = 0; col < 5; col++)
      for (int row = 0; row < 7; row++)
        if (g[col] & (1 << row)) fillRect(x + col * size, y + row * size, size, size, on);
  }
}

// Formats v with one decimal into buf (no float printf needed)
void formatTenths(char *buf, float v) {
  int t = (int)(v * 10 + (v < 0 ? -0.5 : 0.5));
  char sign[2] = {0, 0};
  if (t < 0) { sign[0] = '-'; t = -t; }
  sprintf(buf, "%s%d.%d", sign, t / 10, t % 10);
}

// Thermometer icon at (x, y), mercury level 0..1
void drawThermometer(int x, int y, float level) {
  drawRect(x + 2, y, 7, 30);
  fillCircle(x + 5, y + 33, 5, true);
  int fill = constrain((int)(level * 26), 0, 26);
  fillRect(x + 4, y + 28 - fill, 3, fill + 2, true);
}

// Water-drop icon at (x, y), filled from the bottom 0..1
void drawDrop(int x, int y, float level) {
  for (int i = 0; i <= 14; i++) {   // triangle top
    int half = i * 6 / 14;
    fillRect(x + 6 - half, y + i, 2 * half + 1, 1, true);
  }
  fillCircle(x + 6, y + 15, 6, true);
  int empty = 21 - constrain((int)(level * 21), 0, 21);
  if (empty > 0) fillRect(x + 1, y + 1, 11, empty, false);
  drawLine(x + 6, y, x, y + 14);
  drawLine(x + 6, y, x + 12, y + 14);
  drawCircle(x + 6, y + 15, 6);
}

void drawHeader(const char *title) {
  fillRect(0, 0, OLED_W, 11, true);
  drawText(3, 2, title, 1, false);
  fillCircle(OLED_W - 6, 5, 2, (frame & 1) == 0);
}

// Scene: header + temperature (left) and humidity (right) with bars
void showReading(float t, float h) {
  if (!oledOk) return;
  char buf[12];
  clearFb();
  drawHeader("CLIMATE MONITOR");
  fillRect(64, 14, 1, 50, true);

  drawThermometer(2, 16, (t + 10) / 50.0);   // -10..40 C
  formatTenths(buf, t);
  drawText(16, 22, buf, 2);
  drawText(16, 42, "*C", 1);

  drawDrop(68, 20, h / 100.0);
  sprintf(buf, "%d", (int)(h + 0.5));
  drawText(84, 22, buf, 2);
  drawText(84 + 12 * strlen(buf), 29, "%", 1);
  drawText(84, 42, "RH", 1);

  drawRect(84, 54, 42, 6);
  fillRect(85, 55, constrain((int)(h * 0.4), 0, 40), 4, true);
  oledShow();
}

void showError() {
  if (!oledOk) return;
  char buf[16];
  clearFb();
  drawHeader("CLIMATE MONITOR");
  drawText(10, 26, "SENSOR ERROR", 1);
  sprintf(buf, "STAGE %d", errStage);
  drawText(10, 40, buf, 1);
  oledShow();
}

void setup() {
  Bridge.begin();
  pinMode(DHT_PIN, INPUT_PULLUP);

  Wire.begin();
  oledOk = oledBegin();
  if (oledOk) {
    clearFb();
    drawText(10, 28, "READING SENSOR...", 1);
    oledShow();
  }
}

void loop() {
  float t, h;
  frame++;
  if (readDHT22(t, h)) {
    Bridge.notify("dht_reading", t, h);   // send to Python
    showReading(t, h);
  } else {
    Bridge.notify("dht_error", errStage, idleLevel, (int)releaseUs);
    showError();
  }
  delay(2000);   // DHT22 needs at least 2 s between reads
}
